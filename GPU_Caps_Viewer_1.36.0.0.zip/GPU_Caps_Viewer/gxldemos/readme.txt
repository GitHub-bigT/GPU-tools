All these demos and many more are available with GeeXLab code sample pack.
You can download GeeXLab and the code sample pack from this link:
http://www.geeks3d.com/geexlab/downloads/
