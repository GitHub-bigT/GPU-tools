GPU Caps Viewer
Swiss Made Graphics Card Information Utility
GPU Capabilities Viewer & OpenGL, OpenCL and Vulkan API Support
Copyright � 2007-2017 Geeks3D, All rights reserved.
http://www.Geeks3D.com
http://www.oZone3D.Net/gpu_caps_viewer/

GPU Caps Viewer is a freeware video card information utility that quickly describes 
the essential capabilities of your graphics card/GPU including GPU type, amount of 
VRAM , OpenGL, Vulkan, OpenCL and CUDA API support level, OpenGL API extensions database 
and general system configuration, as well as a GPU-Stress-Test functionality (GPU-Burner).

Visit GPU Caps Viewer homepage at http://www.oZone3D.net/gpu_caps_viewer/
for new updates and changeLog.

GPU Caps Viewer uses the ZoomGPU engine to retrieve graphics card data. 
More information about ZoomGPU: http://www.ozone3d.net/zoomgpu/

GPU Caps Viewer uses the GeeXLab simplified SDK for Vulkan and Direct3D 12 demos 
in the 3D Demos panel. 
More information about GeeXLab SDK: http://www.geeks3d.com/geexlab/sdk/
You can contact me at jegx@ozone3d.net for more details about GeeXLab SDK.


Enjoy!
.:JeGX:.
